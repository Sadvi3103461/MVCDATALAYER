﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvc11.ViewModel
{
    public class EmployeeRecordsViewModel
    {
        public List<EmployeeViewModel> MyEmployees { get; set; }
    }
}